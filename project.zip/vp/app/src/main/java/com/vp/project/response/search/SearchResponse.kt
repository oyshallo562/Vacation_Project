package com.vp.project.response.search

data class SearchResponse(
    val searchPoiInfo: SearchPoiInfo
)