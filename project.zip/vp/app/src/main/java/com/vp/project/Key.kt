package com.vp.project

object Key {
    const val TMAP_API = "l7xxf7a710a6a1444c13ad115e4a05b53f28"

    // AIzaSyC-j_A3WXarUCF3w4c0f8AbjiWGLC5awhs
}