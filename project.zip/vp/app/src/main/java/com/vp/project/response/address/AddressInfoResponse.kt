package com.vp.project.response.address

data class AddressInfoResponse(
    val addressInfo: AddressInfo
)