package com.vp.project

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import androidx.fragment.app.replace
import androidx.fragment.app.setFragmentResultListener
import com.vp.project.databinding.FragmentHomeBinding
import com.vp.project.model.SearchResultEntity

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val view = binding.root

        //childFragmentManager.popBackStack()


        setFragmentResultListener("requestKey2") { requestKey, bundle ->
            val a = bundle.getInt("bundleKey2")
            if (a == 1) {
                parentFragmentManager.commit {
                    remove(SearchConfirmFragment())
                    remove(SearchFragment())
                    replace<HomeFragment>(R.id.nav_host_fragment_activity_main)
                    //setReorderingAllowed(true)
                    //popBackStackImmediate()
                    //replace<HomeFragment>(R.id.nav_host_fragment_activity_main)
                    //setReorderingAllowed(true)
                    //addToBackStack("name") // name can be null
                }
            }
        }




        return view

    }



}