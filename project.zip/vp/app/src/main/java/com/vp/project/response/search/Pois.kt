package com.vp.project.response.search

data class Pois(
    val poi: List<Poi>
)