package com.vp.project.model

data class PlaceUploadEntity (
    var uid :String? = null,
    var name :String? = null,
    var text :String? = null,
    var latitude: Float? = null,
    var longitude: Float? = null
)