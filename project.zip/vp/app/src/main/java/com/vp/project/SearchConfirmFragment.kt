package com.vp.project

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.vp.project.databinding.FragmentSearchBinding
import com.vp.project.databinding.FragmentSearchConfirmBinding
import com.vp.project.model.PlaceUploadEntity
import com.vp.project.model.SearchResultEntity

class SearchConfirmFragment : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //val a : SearchResultEntity? = arguments?.getParcelable("Key")
        //Log.d("data : ", a?.name.toString())

    }

    private var _binding: FragmentSearchConfirmBinding? = null
    private val binding get() = _binding!!
    private var firestore : FirebaseFirestore? = null
    var auth : FirebaseAuth? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentSearchConfirmBinding.inflate(inflater, container, false)
        val view = binding.root

        // Inflate the layout for this fragment
        val button = view?.findViewById<Button>(R.id.Confirm_Button)

        button?.setOnClickListener {
            val ContexEditText = view.findViewById<EditText>(R.id.Context_Edittext)
            var PlaceUploadDTO = PlaceUploadEntity()

            setFragmentResultListener("requestKey") { requestKey, bundle ->
                val a = bundle.getParcelable<SearchResultEntity>("bundleKey")
                PlaceUploadDTO.latitude = a?.locationLatLng?.latitude
                PlaceUploadDTO.longitude = a?.locationLatLng?.longitude
                PlaceUploadDTO.name = a?.name
            }
            PlaceUploadDTO.uid = auth?.currentUser?.uid
            PlaceUploadDTO.text = ContexEditText.text.toString()

            auth = Firebase.auth
            firestore = Firebase.firestore

            firestore!!.collection("Pin")?.document(auth?.currentUser?.uid!!)?.set(PlaceUploadDTO)

            setFragmentResult("requestKey2", bundleOf("bundleKey2" to 1))
            parentFragmentManager.beginTransaction()
                .replace(R.id.nav_host_fragment_activity_main, HomeFragment())
                .commit()

            parentFragmentManager.commit {
                replace<SearchFragment>(R.id.nav_host_fragment_activity_main)
                setReorderingAllowed(true)
                //addToBackStack("name") // name can be null
            }


        }
        return view
    }




}